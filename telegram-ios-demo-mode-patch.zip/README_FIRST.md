# Telegram Demo Studio V2

Этот ZIP заменяет предыдущий пакет Demo Mode.

Что внутри:

1. `0001-...patch` удаляет старую фальшивую авторизацию и старый Demo Mode.
2. `0002-...patch` добавляет Demo Studio V2 поверх обычного Telegram.

## Как применить

1. В корне своего GitHub-репозитория замените старый файл
   `telegram-ios-demo-mode-patch.zip` новым ZIP с тем же именем.
2. Откройте **Actions → Apply Demo Patch → Run workflow**.
3. Дождитесь зелёной галочки. Этот action применит оба патча и сохранит код в
   ветке `master`.
4. Затем откройте новый action
   **Actions → Build Demo Studio V2 → Run workflow**.
5. После зелёной галочки скачайте artifact
   `TelegramDemoStudioV2-IPA`.

Не запускайте старый `Build Demo IPA`: он оставлен только для истории и может
содержать прежние ручные исправления.

Новая сборка:

- использует runner macOS 26 и Xcode 26.2;
- скачивает `rlottie` и `tgcalls` из официальных репозиториев Telegram;
- импортирует fake-signing identity из исходников Telegram;
- перед сборкой возвращает `minimum_os_version` к `13.0`.

Последний пункт не превращает сборку в «iOS 13». SDK и Xcode остаются версии
26.2, а IPA работает на iOS 26. Низкий deployment target нужен, чтобы старые
части исходников Telegram не превращали предупреждения iOS 26 в ошибки
компиляции.

## Где искать функции

- **Настройки → Demo Studio**
- **Чаты → ДЕМО**
- Уникальный NFT Gift → **⋯ → ДЕМО: Подарил мне**

Все синтетические профили, чаты, сообщения, Stars, подарки и медиа хранятся
локально и отдельно от Telegram/Postbox. Надпись `ДЕМО` реализована отдельно в
`DemoStudioWatermarkView.swift`.
